export type Priority = 'low' | 'medium' | 'high'

export interface Todo {
  id: string
  title: string
  priority: Priority
  completed: boolean
}

export const priorityColors = {
  low: 'bg-green-500',
  medium: 'bg-orange-500',
  high: 'bg-red-500',
}