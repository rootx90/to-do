import { useState } from 'react'
import { Todo, Priority } from '../types'

interface AddTodoFormProps {
  onAdd: (todo: Todo) => void
}

const AddTodoForm = ({ onAdd }: AddTodoFormProps) => {
  const [title, setTitle] = useState('')
  const [priority, setPriority] = useState<Priority>('low')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    const newTodo: Todo = {
      id: Date.now().toString(),
      title: title.trim(),
      priority,
      completed: false,
    }

    onAdd(newTodo)
    setTitle('')
    setPriority('low')
  }

  return (
    <form onSubmit={handleSubmit} className="mb-6 space-y-4">
      <div className="flex gap-4">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Add a new todo..."
          className="flex-1 p-2 rounded border bg-background"
        />
        <select
          value={priority}
          onChange={(e) => setPriority(e.target.value as Priority)}
          className="p-2 rounded border bg-background"
        >
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <button
          type="submit"
          className="px-4 py-2 bg-primary text-primary-foreground rounded hover:opacity-90"
        >
          Add Todo
        </button>
      </div>
    </form>
  )
}

export default AddTodoForm