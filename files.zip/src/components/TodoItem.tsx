import { useState } from 'react'
import { Todo, priorityColors } from '../types'
import { Pencil, Trash2, Check, X } from 'lucide-react'

interface TodoItemProps {
  todo: Todo
  onDelete: (id: string) => void
  onEdit: (id: string, newTodo: Partial<Todo>) => void
}

const TodoItem = ({ todo, onDelete, onEdit }: TodoItemProps) => {
  const [isEditing, setIsEditing] = useState(false)
  const [editedTitle, setEditedTitle] = useState(todo.title)

  const handleEdit = () => {
    if (isEditing) {
      onEdit(todo.id, { title: editedTitle })
      setIsEditing(false)
    } else {
      setIsEditing(true)
    }
  }

  const handleCancel = () => {
    setEditedTitle(todo.title)
    setIsEditing(false)
  }

  return (
    <div className={`p-4 rounded-lg border ${todo.completed ? 'opacity-60' : ''} bg-card`}>
      <div className="flex items-center gap-4">
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => onEdit(todo.id, { completed: !todo.completed })}
          className="w-5 h-5"
        />
        
        {isEditing ? (
          <input
            type="text"
            value={editedTitle}
            onChange={(e) => setEditedTitle(e.target.value)}
            className="flex-1 bg-background p-2 rounded"
            autoFocus
          />
        ) : (
          <span className={`flex-1 ${todo.completed ? 'line-through' : ''}`}>
            {todo.title}
          </span>
        )}

        <div className={`w-3 h-3 rounded-full ${priorityColors[todo.priority]}`} />
        
        <div className="flex gap-2">
          {isEditing ? (
            <>
              <button onClick={handleEdit} className="p-2 hover:bg-accent rounded">
                <Check className="w-4 h-4" />
              </button>
              <button onClick={handleCancel} className="p-2 hover:bg-accent rounded">
                <X className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <button onClick={handleEdit} className="p-2 hover:bg-accent rounded">
                <Pencil className="w-4 h-4" />
              </button>
              <button onClick={() => onDelete(todo.id)} className="p-2 hover:bg-accent rounded">
                <Trash2 className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

export default TodoItem