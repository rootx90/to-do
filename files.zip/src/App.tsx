import { useState, useEffect } from 'react'
import { Moon, Sun } from 'lucide-react'
import { Todo } from './types'
import TodoList from './components/TodoList'
import AddTodoForm from './components/AddTodoForm'
import { ThemeToggle } from './components/ThemeToggle'

function App() {
  const [todos, setTodos] = useState<Todo[]>(() => {
    const savedTodos = localStorage.getItem('todos')
    return savedTodos ? JSON.parse(savedTodos) : []
  })

  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos))
  }, [todos])

  const addTodo = (todo: Todo) => {
    setTodos([...todos, todo])
  }

  const deleteTodo = (id: string) => {
    setTodos(todos.filter(todo => todo.id !== id))
  }

  const editTodo = (id: string, newTodo: Partial<Todo>) => {
    setTodos(todos.map(todo => 
      todo.id === id ? { ...todo, ...newTodo } : todo
    ))
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <div className="container mx-auto p-4">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Todo List Pro</h1>
          <ThemeToggle />
        </div>
        
        <AddTodoForm onAdd={addTodo} />
        
        <TodoList 
          todos={todos}
          onDelete={deleteTodo}
          onEdit={editTodo}
        />
      </div>
    </div>
  )
}

export default App